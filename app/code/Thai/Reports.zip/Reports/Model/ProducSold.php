<?php

namespace Thai\Reports\Block;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Zend_Mail_Transport_Smtp;
use Zend_Mail;
use Thai\Reports\Helper\Data;

class ProductSold extends \Magento\Framework\View\Element\Template
{
    protected $helperData;
    protected $_itemFactory;
    protected $_date;
    protected $orderRepository;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        Data $helperData,
        \Magento\Sales\Model\Order\ItemFactory $itemFactory,
        TimezoneInterface $date,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
    )
    {
        $this->orderRepository = $orderRepository;
        $this->_date = $date;
        $this->_itemFactory = $itemFactory;
        $this->helperData = $helperData;
    }

    public function getOrderStatus($orderId)
    {
        $order = $this->orderRepository->get($orderId);
        $state = $order->getState();
        return $state;
    }

    public function csvFile()
    {
        $date = $this->_date->date()->format('Y-m-d');
        $csv = 'Reports-'.$date.'.csv';
        $handle = fopen($csv, 'w');
        $heading = [
            __('Id'),
            __('SKU'),
            __('Price')
        ];
        fputcsv($handle, $heading);
        return $this->downloadCsv($csv);
    }

    public function getProduct()
    {
        $settingTime = $this->helperData->getConfig('time');
        $settingTime = str_replace(',', ':', $settingTime);
        $currentStoreTime = $this->_date->date()->format('Y-m-d '.$settingTime);
        $lastday = strtotime('-1 day', strtotime($currentStoreTime));
        $lastday = date('Y-m-d h:i:s', $lastday);
        $order = $this->_itemFactory->create()->getCollection()
        ->addFieldToFilter('created_at', ['gteq' => $lastday])
        ->addFieldToFilter('created_at', ['lteq' => $currentStoreTime])
        ->getData();
        if (count($order) > 0) {
            foreach ($order as $orders) {
                $orderId = $orders['order_id'];
                if($this->getOrderStatus($orderId) === 'processing') {
                    $row = [
                        $orders['product_id'],
                        $orders['sku'],
                        $orders['qty_shipped']
                    ];
                }
            }
            return $row;
        }
    }
    
    public function downloadCsv($file)
    {
        if (file_exists($file)) {
            //set appropriate headers
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename='.basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();flush();
            readfile($file);
        }
    }
}
