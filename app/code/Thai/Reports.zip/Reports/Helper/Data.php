<?php

namespace Thai\Reports\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    const XML_PATH_SECTION = 'report/';
    const XML_PATH_GROUP = 'configurable_cron/';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * Data constructor.
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
    )
    {
        $this->_scopeConfig = $context;
        $this->_storeManager = $storeManager;
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        parent::__construct($context);
    }

    // get config value
	public function getConfigValue($field, $storeId = null)
	{
		return $this->scopeConfig->getValue(
			$field, ScopeInterface::SCOPE_STORE, $storeId
		);
	}

	public function getConfig($code, $storeId = null)
	{
		return $this->getConfigValue(self::XML_PATH_SECTION .self::XML_PATH_GROUP. $code, $storeId);
	}

    // check enable extension
    public function isEnable ()
    {
        $enable = true;
        if ($this->getConfig('enable_module') != 0)
        {
            return $enable;
        }
    }

    /**
     * @param $sender
     * @param $receiver
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws \Magento\Framework\Exception\MailException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function sendMail($sender, $receiver)
    {
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->_storeManager->getStore()->getId());
        $templateVars = array('store' => $this->_storeManager->getStore(),);
        $prorocol = $this->helperData->getConfig('protocol');
        $smtpHost = $this->helperData->getConfig('smtphost');
        $smtpPost = $this->helperData->getConfig('smtppost');
        $auth = strtolower($this->helperData->getConfig('auth'));
        $username = $this->helperData->getConfig('username');
        $password = $this->helperData->getConfig('password');
        $password = $this->encrypt->decrypt($password);
        $smtpConf = [
            'auth' => $auth,
            'ssl' => $prorocol,
            'port' => $smtpPost,
            'username' => $username,
            'password' => $password
        ];
        $this->inlineTranslation->suspend();
        $transport = $this->_transportBuilder->setTemplateIdentifier('report_template')
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($sender)
            ->addTo($receiver)
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }
}