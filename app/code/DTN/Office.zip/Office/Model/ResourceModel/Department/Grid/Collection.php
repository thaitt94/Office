<?php

namespace DTN\Office\Model\ResourceModel\Department\Grid;

use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;

/**
 * Collection for displaying grid of Department
 */
class Collection extends SearchResult
{

}