<?php

namespace DTN\Label\Model\ResourceModel\Label\Grid;

use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;

/**
 * Collection for displaying grid of label
 */
class Collection extends SearchResult
{

}