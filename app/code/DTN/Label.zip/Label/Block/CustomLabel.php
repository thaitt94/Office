<?php

namespace DTN\Label\Block;

use Magento\Framework\View\Element\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use DTN\Label\Model\LabelFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;

class CustomLabel extends Template
{
    protected $_labelFactory;
    protected $registry;
    protected $_date;
    protected $storeManager;
    protected $_dateFactory;

    public function __construct(
        Context $context,
        Registry $registry,
        LabelFactory $labelFactory,
        TimezoneInterface $date,
        StoreManagerInterface $storeManager,
        DateTimeFactory $dateFactory,
        array $data = []
    )
    {
        $this->_dateFactory = $dateFactory;
        $this->storeManager =  $storeManager;
        $this->_date =  $date;
        $this->_labelFactory = $labelFactory;
        $this->_registry = $registry;
        parent::__construct($context, $data);
    }

    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
    public function getLabel()
    {
        $result = [];
        $pathImg = 'pub/media/dtn/tmp/label/';
        $label = $this->_labelFactory->create()->getCollection()
        ->load()->getData();
        foreach($label as $value) {
            if($value['name'] === 'FreeShipping'){
                $size = $value['label_text_size'];
                $result['FreeShipping'] = '<img src = "'.$this->getBaseUrl().$pathImg.$value['image'].'" width="30" height="30">';
            } else {
                if($value['name'] === 'New'){
                    $result['New'] = '<div class="new_label"><img src = "'.$this->getBaseUrl().$pathImg.$value['image'].'" width="'.$value['label_text_size'].'" height="'.$value['label_text_size'].'"></div>';
                } else {
                    if($value['name'] === 'Sale'){
                        $result['Sale'] = '<img src = "'.$this->getBaseUrl().$pathImg.$value['image'].'" width="'.$value['label_text_size'].'" height="'.$value['label_text_size'].'">';
                    }
                }
            }
        }
        return $result;
    }

    public function getcurrentStoreTime()
    {
        return $this->_date->date()->format('Y-m-d H:i:s');
    }
    public function timeZone()
    {
        return $this->storeManager->getStore()->getConfig('general/locale/timezone');
    }

    public function test()
    {
        return $this->_dateFactory->create()->gmtDate();
    }

}
