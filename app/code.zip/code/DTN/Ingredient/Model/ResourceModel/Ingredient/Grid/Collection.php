<?php

namespace DTN\Ingredient\Model\ResourceModel\Ingredient\Grid;

use Magento\Framework\View\Element\UiComponent\DataProvider\SearchResult;

/**
 * Collection for displaying grid of Ingredient
 */
class Collection extends SearchResult
{

}