<?php

namespace DTN\Label\Block\Adminhtml;

use Magento\Framework\View\Element\Template;

class LabelOption extends Template
{
    protected $_template = 'labeloption.phtml';
}