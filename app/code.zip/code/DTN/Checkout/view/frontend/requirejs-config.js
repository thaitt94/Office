var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'DTN_Checkout/js/model/shipping-save-processor/default'
        }
    }
};

// var config = {
//     config: {
//         mixins: {
//             'Magento_Checkout/js/action/set-shipping-information': {
//                 'DTN_Checkout/js/model/shipping-save-processor/default': true
//             }
//         }
//     }
// };